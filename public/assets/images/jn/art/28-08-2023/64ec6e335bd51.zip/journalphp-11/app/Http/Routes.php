<?php 

namespace Http\router;

class Routes extends Controller 
{
    
}
