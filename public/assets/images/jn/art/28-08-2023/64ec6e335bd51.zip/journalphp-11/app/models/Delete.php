<?php
final class Delete 
{
    
}
