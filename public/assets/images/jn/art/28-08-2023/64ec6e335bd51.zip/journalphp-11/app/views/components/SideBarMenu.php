<div class="bookcase">
  <h3 tabindex="0" class="bookcase-name">Architecture</h3>
  <ul class="bookcase-bookshelf-list">
    <li class="bookcase-bookshelf-list-item">
      <a href="/libraries/603/subjects/57/bookcases/69?sort=title" id="ember1115" class="active ember-view" tabindex="0">                <span>All Journals</span></a>
    </li>
      <li class="bookcase-bookshelf-list-item">
        <a href="/libraries/603/subjects/57/bookcases/69/bookshelves/173?sort=title" id="ember1119" class="ember-view" tabindex="0"><span>Architectural History</span></a>
        <div id="ember1126" class="ember-view"></div>
      </li>
      <li class="bookcase-bookshelf-list-item">
        <a href="/libraries/603/subjects/57/bookcases/69/bookshelves/174?sort=title" id="ember1128" class="ember-view" tabindex="0"><span>Architecture - General/Interdisciplinary</span></a>
        <div id="ember1129" class="ember-view"></div>
      </li>
      <li class="bookcase-bookshelf-list-item">
        <a href="/libraries/603/subjects/57/bookcases/69/bookshelves/180?sort=title" id="ember1131" class="ember-view" tabindex="0"><span>Architecture - Teaching and Professional Issues</span></a>
        <div id="ember1132" class="ember-view"></div>
      </li>
      <li class="bookcase-bookshelf-list-item">
        <a href="/libraries/603/subjects/57/bookcases/69/bookshelves/181?sort=title" id="ember1134" class="ember-view" tabindex="0"><span>Historic Preservation and Cultural Resource Management</span></a>
        <div id="ember1135" class="ember-view"></div>
      </li>
      <li class="bookcase-bookshelf-list-item">
        <a href="/libraries/603/subjects/57/bookcases/69/bookshelves/179?sort=title" id="ember1137" class="ember-view" tabindex="0"><span>Landscape Architecture</span></a>
        <div id="ember1138" class="ember-view"></div>
      </li>
      <li class="bookcase-bookshelf-list-item">
        <a href="/libraries/603/subjects/57/bookcases/69/bookshelves/182?sort=title" id="ember1140" class="ember-view" tabindex="0"><span>Urban, Community and Regional Planning</span></a>
        <div id="ember1141" class="ember-view"></div>
      </li>
  </ul>
</div>