
<script src="<?=ASSETS?>js/vendor.min.js"></script>
<script src="<?=ASSETS?>js/pubs-ui.min.js"></script>
<script>
    const _route="<?=$data['_token']?>"
</script>
<script src="<?=ASSETS?>js/script.js"></script>
<script src="<?=ASSETS?>js/em.js"></script>
</body>

</html>