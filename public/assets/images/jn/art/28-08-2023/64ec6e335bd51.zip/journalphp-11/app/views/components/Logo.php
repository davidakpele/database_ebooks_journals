<div id="ember626" class="ember-view"> 
    <a id="logo-provided-by-link" href="javascript:void(0)"  tabindex="0">
        <h1 class="library-logo has-name">SkyBase Data Center</h1>
        <!-- <img src="<?=ASSETS?>images/logo.png?force_update=true" alt="Logo for University of Cambridge" class="library-logo has-name"> -->
    </a>
</div>