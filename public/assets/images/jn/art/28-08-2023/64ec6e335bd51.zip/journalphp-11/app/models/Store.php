<?php
final class Store
{
    
}
