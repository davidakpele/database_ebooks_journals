<?php
session_start();
require "../app/init.php";
// My Application
$app = new Application();